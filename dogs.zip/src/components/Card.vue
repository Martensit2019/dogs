<template>
  <div  style="margin: 5px; padding: 5px; background-color: #fff; border: 1px solid #c9c9c9">
    <div style="display: flex; flex: 0 0 32%; height: 300px; overflow: hidden">
      <img
        class="object-cover w-full"
        style="
          display: block;
          max-width: 100%;
          height: auto;
          object-fit: cover;
          visibility: visible;
          opacity: 1;
          transition: opacity 1s cubic-bezier(0.5, 0, 0, 1) 0s;
        "
        :src="card.img"
        @click="dogStore.addToFavorite(card.img)"
      />
    </div>
    <div>{{ card.breed }}</div>
  </div>
</template>

<script setup lang="ts">
import { useDogsStore } from '../stores/dogs'

interface ICard {
  id: number
  breed: string
  img: string
}
interface IProps {
  // options: string[]
  card: ICard
}

const dogStore = useDogsStore()

// dogStore.addToFavorite

defineProps<IProps>()



// const addToFavorite = (card: ICard) => {
//   console.log('Fav', str);
  
// }
</script>

<style scoped></style>
