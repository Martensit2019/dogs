<template>
  <header class="border-b-2">
    <div class="container mx-auto">
      <div class="flex w-full py-3">
        <div class="w-72 flex items-center justify-start" @click="dogStore.selected = dogStore.startSelected">DOGGIE</div>
        <BaseSelect :options="dogBreedOptions" />
        <div class="w-72 flex items-center justify-end">Избранное<span v-if="dogStore.favoritesCount">({{ dogStore.favoritesCount }})</span></div>
      </div>
    </div>
  </header>
</template>

<script setup lang="ts">
// import { useAuthStore } from '../../stores/auth'
import { useFetch } from '@vueuse/core'
import { useDogsStore } from '../../stores/dogs'

const dogStore = useDogsStore()


const url = 'https://dog.ceo/api/breeds/list/all'

const { isFetching, error, data } = useFetch(url).json()

const dogBreedOptions = computed(() => data.value && Object.keys(data.value.message))



</script>

<style scoped>
/* @import 'theHeader'; */
</style>
