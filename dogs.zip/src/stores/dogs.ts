import { ref, computed } from 'vue'
import { defineStore } from 'pinia'

interface ICard {
  id: number
  breed: string
  img: string
}

export const useDogsStore = defineStore('dogs', () => {
  const router = useRouter()

  const startSelected = 'Select or Search for a Dog Breed...'

  const selected = ref<string>('Select or Search for a Dog Breed...')
  const favorites = ref<string[]>([])

  const favoritesCount = computed(() => favorites.value.length)

  const aaa = ref<number>(77)
  // const count = ref(0)
  // const doubleCount = computed(() => count.value * 2)
  // function increment() {
  //   count.value++
  // }

  const addToFavorite = (strImg: string) => {
    console.log(strImg)
    if (favorites.value.includes(strImg)) {
      favorites.value = favorites.value.filter((str) => str !== strImg)
    } else {
      favorites.value.push(strImg)
    }
  }

  watch(
    () => selected.value,
    (val) => {
      val === startSelected ? router.push('/') : router.push({ name: 'breeds', params: { breed: val } })
    }
  )

  return { startSelected, selected, favorites, favoritesCount, addToFavorite, aaa }
  // return { count, doubleCount, increment }
})
