<template>
  <div class="container mx-auto">
    params - {{ params.breed }}
    <div v-if="!data">Ytn</div>
    <div class="grid grid-cols-4 gap-4 my-4">
      <Card v-for="breed in dataBreeds" :card="breed" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { useFetch } from '@vueuse/core'
import { useDogsStore } from '../stores/dogs'
const { params } = useRoute()
const dogStore = useDogsStore()
dogStore.selected = params.breed
// params
// :
// {breed: 'borzoi'}

// https://dog.ceo/api/breed/hound/images/random/3

const url = computed(() => `https://dog.ceo/api/breed/${dogStore.selected || params.breed}/images/random/20`)

const { isFetching, error, data } = useFetch(url, { refetch: true }).json()

const dataBreeds = computed(() => data.value && createBreedsData(data.value.message))
const createBreedsData = (data: string[]) => {
  return data.map((str: string, idx: number) => ({
    id: idx,
    breed: str.split('/')[str.split('/').length - 2],
    img: str,
  }))
}
</script>

<style scoped></style>
