<template>
  <div class="container mx-auto">
    <div class="grid grid-cols-4 gap-4 my-4">
      <Card v-for="breed in dataBreeds" :card="breed"/>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useFetch } from '@vueuse/core'
import { useDogsStore } from '../stores/dogs'

const router = useRouter()

const dogStore = useDogsStore()

const url = 'https://dog.ceo/api/breeds/image/random/20'

const { isFetching, error, data } = useFetch(url).json()

const dataBreeds = computed(() => data.value && createBreedsData(data.value.message))

const createBreedsData = (data: string[]) => {
  return data.map((str: string, idx: number) => ({
    id: idx,
    breed: str.split('/')[str.split('/').length - 2],
    img: str,
  }))
}

const onClick = () => {
  // router.push('/ss')
  router.push({name: 'breeds', params: {breed: 'ee'}})
}
</script>
